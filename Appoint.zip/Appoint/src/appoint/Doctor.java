/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package appoint;

import java.util.ArrayList;


public class Doctor extends Person implements PersonMethods {

    private ArrayList<Appointment> Appointments = new ArrayList();

    public Doctor(String firstName, String lastName, String email, int phoneNumber) {
        super(firstName, lastName, email, phoneNumber);
    }

    public void addAppointment(Appointment Appointment) {
        this.Appointments.add(Appointment);
    }

    @Override
    public String getInfo() {
        String str = "";
        for (Appointment st : this.Appointments) {
            str += st.printData() + "\n";
        }
        return "Name : " + this.getFirstName() + " , " + this.getLastName() + "\nEmail : " + this.getEmail() + "\nPhone Number : " + this.getPhoneNumber() + "\nAppointments :" + str;
    }

}
