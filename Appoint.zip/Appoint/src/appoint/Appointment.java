/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package appoint;

import java.util.ArrayList;

public class Appointment {

    private Patient Patient;
    private String Date = "";

    public Appointment(Patient Patient, String date) {
        this.Patient = Patient;
        this.Date = date;
    }

    public Patient getAppointmentsP() {
        return Patient;
    }

    public String printData() {
        return "Patient Name : " + this.Patient.getFirstName() + " "+this.Patient.getLastName() + "\tDate : " + this.Date;
    }
}
