/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package appoint;

public class Patient extends Person implements PersonMethods{

    public Patient(String firstName, String lastName, String email, int phoneNumber) {
        super(firstName, lastName, email, phoneNumber);
    }
    

    @Override
    public String getInfo() {
        return "Name : " + this.getFirstName() + " , " + this.getLastName() + "\nEmail : " + this.getEmail() + "\nPhone Number : " + this.getPhoneNumber();
    }
    
}
