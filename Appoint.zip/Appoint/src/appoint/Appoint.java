/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package appoint;

public class Appoint {

    
    public static void main(String[] args) {
        Doctor doctor = new Doctor("mohammed", "alghamdi", "malgh@gmail.com", 129;
        Doctor doctor1 = new Doctor("saad", "alotaibi", "saadotb@gmail.com", 1027);
        Doctor doctor2 = new Doctor("khaled", "alasmari", "khalasmari@gmail.com",05761);
        Doctor doctor3 = new Doctor("reem", "ahmad","reemmer@gmail.com",05720);

        Patient patient = new Patient("sara", "alessa", "Patient 1", 12);
        Patient patient1 = new Patient("eman", "saad", "Patient 2", 12);
        Patient patient2 = new Patient("ahlam", "khaled", "Patient 3", 12);
        Patient patient3 = new Patient("yara", "ahmad", "Patient 4", 12);
        Patient patient4 = new Patient("lina", "saad", "Patient 5", 12);

        doctor1.addAppointment(new Appointment(patient, "12-1-2022"));
        doctor2.addAppointment(new Appointment(patient2, "1-2-2022"));
        doctor3.addAppointment(new Appointment(patient3, "5-12-2021"));
        doctor.addAppointment(new Appointment(patient4, "7-12-2021"));
        doctor1.addAppointment(new Appointment(patient1, "18-12-2021"));

        doctor1.addAppointment(new Appointment(patient4, "8-11-2021"));
        doctor2.addAppointment(new Appointment(patient1, "9-12-2021"));
        doctor.addAppointment(new Appointment(patient2, "15-12-2021"));
        doctor2.addAppointment(new Appointment(patient2, "1-1-2021"));
        doctor1.addAppointment(new Appointment(patient1, "19-12-2021"));

        doctor1.addAppointment(new Appointment(patient4, "17-12-2021"));
        doctor2.addAppointment(new Appointment(patient, "23-12-2021"));
        doctor3.addAppointment(new Appointment(patient2, "29-12-2021"));
        doctor.addAppointment(new Appointment(patient1, "2-1-2022"));
        doctor1.addAppointment(new Appointment(patient1, "15-1-2022"));

        System.out.println(doctor1.getInfo());

        System.out.println(doctor2.getInfo());

        System.out.println(doctor3.getInfo());

        System.out.println(doctor.getInfo());
    }

}
